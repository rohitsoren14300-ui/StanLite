import './globals.css';
export const metadata = { title: 'StanLite — your store in one link', description: 'Sell downloads, courses and calls from one link in bio.' };
export default function L({ children }) {
  return <html lang="en"><body className="bg-stone-50 text-indigo-950 antialiased">{children}</body></html>;
}
