'use client';
import { useState } from 'react';
export default function Auth() {
  const [mode, setMode] = useState('signup'), [f, setF] = useState({}), [err, setErr] = useState('');
  const set = k => e => setF({ ...f, [k]: e.target.value });
  async function go(e) {
    e.preventDefault(); setErr('');
    const r = await fetch('/api/auth', { method: 'POST', body: JSON.stringify({ mode, ...f }) });
    if (r.ok) location.href = '/dashboard'; else setErr((await r.json()).error);
  }
  const inp = 'w-full rounded-xl border border-indigo-950/20 bg-white px-3 py-2.5 outline-none focus:border-indigo-950';
  return (
    <main className="mx-auto max-w-sm px-5 py-20">
      <a href="/" className="font-bold">StanLite</a>
      <h1 className="mt-6 text-2xl font-bold">{mode === 'signup' ? 'Create your store' : 'Welcome back'}</h1>
      <form onSubmit={go} className="mt-6 space-y-3">
        {mode === 'signup' && <input className={inp} placeholder="Handle (your link: /handle)" onChange={set('handle')} required />}
        <input className={inp} type="email" placeholder="Email" onChange={set('email')} required />
        <input className={inp} type="password" placeholder="Password (8+ characters)" onChange={set('password')} required />
        {err && <p className="text-sm text-red-700">{err}</p>}
        <button className="w-full rounded-xl bg-indigo-950 py-2.5 font-semibold text-white">{mode === 'signup' ? 'Create account' : 'Log in'}</button>
      </form>
      <button onClick={() => setMode(mode === 'signup' ? 'login' : 'signup')} className="mt-4 text-sm underline">
        {mode === 'signup' ? 'Have an account? Log in' : 'New here? Create an account'}
      </button>
    </main>
  );
}
