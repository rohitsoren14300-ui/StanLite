import db from '@/lib/db';
export async function GET(req, { params }) {
  const { id } = await params;
  const p = db.prepare('select url from products where id=?').get(id);
  if (!p) return new Response('Not found', { status: 404 });
  db.prepare('update products set clicks=clicks+1 where id=?').run(id);
  return Response.redirect(p.url, 302);
}
