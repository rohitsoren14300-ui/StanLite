import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import Workspace from './workspace';
export default async function Page() {
  const u = await getUser();
  if (!u) redirect('/login');
  return <Workspace user={{ handle: u.handle, name: u.name, bio: u.bio, plan: u.plan }} />;
}
