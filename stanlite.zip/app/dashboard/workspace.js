'use client';
import { useState, useEffect } from 'react';
const KINDS = { download: 'Digital download', course: 'Course', coaching: 'Coaching call', link: 'Link' };
const inp = 'w-full rounded-xl border border-indigo-950/20 bg-white px-3 py-2.5 outline-none focus:border-indigo-950';
export default function Workspace({ user }) {
  const [items, setItems] = useState(null), [q, setQ] = useState(''), [kind, setKind] = useState('');
  const [f, setF] = useState({ title: '', description: '', price: '', url: '', kind: 'download' });
  const [msg, setMsg] = useState(''), [busy, setBusy] = useState(false);
  const [prof, setProf] = useState({ name: user.name, bio: user.bio });
  const pro = user.plan === 'pro';
  const load = async () => setItems(await (await fetch(`/api/products?q=${encodeURIComponent(q)}&kind=${kind}`)).json());
  useEffect(() => { const t = setTimeout(load, 200); return () => clearTimeout(t); }, [q, kind]);
  const set = k => e => setF({ ...f, [k]: e.target.value });
  async function add(e) {
    e.preventDefault(); setMsg('');
    const r = await fetch('/api/products', { method: 'POST', body: JSON.stringify(f) });
    if (r.ok) { setF({ title: '', description: '', price: '', url: '', kind: f.kind }); load(); } else setMsg((await r.json()).error);
  }
  async function ai() {
    if (!f.title) return setMsg('Add a title first, then let AI write the description.');
    setBusy(true); setMsg('');
    const r = await fetch('/api/ai', { method: 'POST', body: JSON.stringify({ title: f.title, kind: KINDS[f.kind] }) });
    const d = await r.json(); setBusy(false);
    if (r.ok) setF({ ...f, description: d.text }); else setMsg(d.error);
  }
  async function del(id) { await fetch(`/api/products?id=${id}`, { method: 'DELETE' }); load(); }
  async function upgrade() { const r = await fetch('/api/checkout', { method: 'POST' }); const d = await r.json(); if (d.url) location.href = d.url; else setMsg('Stripe is not configured yet.'); }
  async function logout() { await fetch('/api/auth', { method: 'POST', body: JSON.stringify({ mode: 'logout' }) }); location.href = '/'; }
  const saveProf = () => fetch('/api/profile', { method: 'POST', body: JSON.stringify(prof) });
  return (
    <div className="mx-auto max-w-5xl px-5 py-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <b className="text-lg">StanLite</b>
        <div className="flex items-center gap-3 text-sm">
          <a href={`/${user.handle}`} target="_blank" className="underline">View store /{user.handle}</a>
          {pro ? <span className="rounded-full bg-amber-300 px-3 py-1 font-semibold">Pro</span> :
            <button onClick={upgrade} className="rounded-full bg-indigo-950 px-4 py-1.5 font-semibold text-white">Upgrade to Pro</button>}
          <button onClick={logout} className="text-indigo-950/60">Log out</button>
        </div>
      </header>
      <div className="mt-8 grid gap-8 md:grid-cols-[1fr_1.3fr]">
        <section className="space-y-3">
          <h2 className="font-bold">Your page</h2>
          <input className={inp} placeholder="Display name" value={prof.name} onChange={e => setProf({ ...prof, name: e.target.value })} onBlur={saveProf} />
          <input className={inp} placeholder="Short bio" value={prof.bio} onChange={e => setProf({ ...prof, bio: e.target.value })} onBlur={saveProf} />
          <h2 className="pt-4 font-bold">Add a product</h2>
          <form onSubmit={add} className="space-y-3">
            <input className={inp} placeholder="Title" value={f.title} onChange={set('title')} required />
            <div className="flex gap-2">
              <select className={inp} value={f.kind} onChange={set('kind')}>{Object.entries(KINDS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
              <input className={inp + ' max-w-28'} type="number" min="0" step="0.01" placeholder="Price $" value={f.price} onChange={set('price')} />
            </div>
            <input className={inp} placeholder="Where buyers go (Stripe link, Calendly, Drive…)" value={f.url} onChange={set('url')} required />
            <textarea className={inp} rows={3} placeholder="Description" value={f.description} onChange={set('description')} />
            <button type="button" onClick={ai} disabled={busy} className="rounded-xl border border-indigo-950 px-3 py-2 text-sm font-semibold">{busy ? 'Writing…' : `✨ Write with AI${pro ? '' : ' (Pro)'}`}</button>
            {msg && <p className="text-sm text-red-700">{msg}</p>}
            <button className="w-full rounded-xl bg-indigo-950 py-2.5 font-semibold text-white">Add to store</button>
          </form>
        </section>
        <section>
          <div className="flex gap-2">
            <input className={inp} placeholder="Search products" value={q} onChange={e => setQ(e.target.value)} />
            <select className={inp + ' max-w-40'} value={kind} onChange={e => setKind(e.target.value)}><option value="">All types</option>{Object.entries(KINDS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
          </div>
          <ul className="mt-4 space-y-3">
            {items === null && <li className="text-indigo-950/50">Loading…</li>}
            {items?.length === 0 && <li className="rounded-2xl border border-dashed border-indigo-950/30 p-8 text-center text-indigo-950/60">{q || kind ? 'No products match your search.' : 'Your store is empty. Add your first product on the left and it appears on your public page instantly.'}</li>}
            {items?.map(p => (
              <li key={p.id} className="flex items-start justify-between gap-3 rounded-2xl border border-indigo-950/15 bg-white p-4">
                <div><b>{p.title}</b> <span className="text-sm text-indigo-950/60">{p.price > 0 ? `$${p.price}` : 'Free'} · {KINDS[p.kind]}</span>
                  {p.description && <p className="mt-1 text-sm text-indigo-950/70">{p.description}</p>}
                  <p className="mt-1 text-xs text-indigo-950/50">{p.clicks} clicks · added {p.created.slice(0, 10)}</p></div>
                <button onClick={() => del(p.id)} className="text-sm text-red-700">Delete</button>
              </li>))}
          </ul>
        </section>
      </div>
    </div>
  );
}
