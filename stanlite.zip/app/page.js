const F = [['One link, your whole store', 'Sell downloads, courses and coaching calls from a single page at /yourname.'], ['AI writes the copy', 'Type a title, get a sharp product description in one click.'], ['See what sells', 'Every product tracks clicks, so you know what your audience wants.']];
export default function Home() {
  return (
    <main>
      <nav className="mx-auto flex max-w-5xl items-center justify-between px-5 py-5"><b className="text-lg">StanLite</b><a href="/login" className="text-sm font-semibold underline">Log in</a></nav>
      <section className="mx-auto max-w-3xl px-5 pb-16 pt-16 text-center">
        <h1 className="text-5xl font-extrabold leading-tight tracking-tight sm:text-6xl">Turn your audience into income.</h1>
        <p className="mx-auto mt-5 max-w-xl text-lg text-indigo-950/70">Build a link-in-bio store in minutes. Add products, let AI write the pitch, share one link.</p>
        <a href="/login" className="mt-8 inline-block rounded-full bg-amber-300 px-8 py-3.5 text-lg font-bold">Create your store free</a>
      </section>
      <section className="mx-auto grid max-w-5xl gap-4 px-5 sm:grid-cols-3">
        {F.map(([t, d]) => <div key={t} className="rounded-2xl border border-indigo-950/15 bg-white p-6"><h3 className="font-bold">{t}</h3><p className="mt-2 text-indigo-950/70">{d}</p></div>)}
      </section>
      <section className="mx-auto grid max-w-3xl gap-4 px-5 py-16 sm:grid-cols-2">
        <div className="rounded-2xl border border-indigo-950/15 bg-white p-6"><h3 className="text-xl font-bold">Free</h3><p className="text-3xl font-extrabold">$0</p><p className="mt-3 text-indigo-950/70">Up to 3 products. “Made with StanLite” badge.</p></div>
        <div className="rounded-2xl bg-indigo-950 p-6 text-white"><h3 className="text-xl font-bold">Pro</h3><p className="text-3xl font-extrabold">$19<span className="text-base font-normal">/mo</span></p><p className="mt-3 text-white/80">Unlimited products, AI writing, no badge.</p></div>
      </section>
    </main>
  );
}
