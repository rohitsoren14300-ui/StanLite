import { notFound } from 'next/navigation';
import db from '@/lib/db';
export const dynamic = 'force-dynamic';
export default async function Store({ params }) {
  const { handle } = await params;
  const u = db.prepare('select * from users where handle=?').get(handle.toLowerCase());
  if (!u) notFound();
  const items = db.prepare('select * from products where user_id=? order by id desc').all(u.id);
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col items-center px-5 py-12">
      <div className="grid h-20 w-20 place-items-center rounded-full bg-indigo-950 text-3xl font-bold text-amber-300">{(u.name || u.handle)[0].toUpperCase()}</div>
      <h1 className="mt-4 text-2xl font-bold">{u.name || u.handle}</h1>
      {u.bio && <p className="mt-1 text-center text-indigo-950/70">{u.bio}</p>}
      <div className="mt-8 w-full space-y-3">
        {items.length === 0 && <p className="text-center text-indigo-950/50">Nothing for sale yet.</p>}
        {items.map(p => (
          <a key={p.id} href={`/go/${p.id}`} className="block rounded-2xl border border-indigo-950/15 bg-white p-4 transition hover:border-indigo-950">
            <div className="flex items-baseline justify-between gap-3"><b>{p.title}</b><span className="shrink-0 font-semibold">{p.price > 0 ? `$${p.price}` : 'Free'}</span></div>
            {p.description && <p className="mt-1 text-sm text-indigo-950/70">{p.description}</p>}
          </a>
        ))}
      </div>
      {u.plan !== 'pro' && <a href="/" className="mt-auto pt-12 text-xs text-indigo-950/50">Made with StanLite</a>}
    </main>
  );
}
