import db from '@/lib/db';
import { getUser } from '@/lib/auth';
const FREE_LIMIT = 3;
export async function GET(req) {
  const u = await getUser(); if (!u) return Response.json([], { status: 401 });
  const p = new URL(req.url).searchParams, q = `%${p.get('q') || ''}%`, k = p.get('kind') || '';
  return Response.json(db.prepare("select * from products where user_id=? and (title like ? or description like ?) and (?='' or kind=?) order by id desc").all(u.id, q, q, k, k));
}
export async function POST(req) {
  const u = await getUser(); if (!u) return Response.json({ error: 'Sign in first.' }, { status: 401 });
  const b = await req.json();
  if (!b.title?.trim() || !/^https?:\/\//.test(b.url || '')) return Response.json({ error: 'Add a title and a link starting with http(s)://' }, { status: 400 });
  const n = db.prepare('select count(*) c from products where user_id=?').get(u.id).c;
  if (u.plan !== 'pro' && n >= FREE_LIMIT) return Response.json({ error: `Free plan is limited to ${FREE_LIMIT} products. Upgrade to Pro for unlimited.` }, { status: 402 });
  db.prepare('insert into products(user_id,title,description,price,url,kind) values(?,?,?,?,?,?)').run(u.id, b.title.trim(), b.description || '', Number(b.price) || 0, b.url, b.kind || 'download');
  return Response.json({ ok: 1 });
}
export async function DELETE(req) {
  const u = await getUser(); if (!u) return Response.json({}, { status: 401 });
  db.prepare('delete from products where id=? and user_id=?').run(new URL(req.url).searchParams.get('id'), u.id);
  return Response.json({ ok: 1 });
}
