import Stripe from 'stripe';
import { getUser } from '@/lib/auth';
export async function POST() {
  const u = await getUser(); if (!u) return Response.json({}, { status: 401 });
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const s = await stripe.checkout.sessions.create({
    mode: 'subscription', line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
    client_reference_id: String(u.id), customer_email: u.email,
    success_url: `${process.env.APP_URL}/dashboard?upgraded=1`, cancel_url: `${process.env.APP_URL}/dashboard`,
  });
  return Response.json({ url: s.url });
}
