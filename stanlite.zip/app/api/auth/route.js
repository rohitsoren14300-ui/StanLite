import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import db from '@/lib/db';
import { setSession } from '@/lib/auth';
const RESERVED = ['login', 'dashboard', 'api', 'go', 'admin'];
export async function POST(req) {
  const { mode, email, password, handle } = await req.json();
  if (mode === 'logout') { (await cookies()).delete('s'); return Response.json({ ok: 1 }); }
  if (mode === 'signup') {
    const h = (handle || '').toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (!email || (password || '').length < 8 || h.length < 3 || RESERVED.includes(h))
      return Response.json({ error: 'Use a valid email, 8+ character password and an available 3+ character handle.' }, { status: 400 });
    try {
      const r = db.prepare('insert into users(email,hash,handle,name) values(?,?,?,?)').run(email.toLowerCase(), bcrypt.hashSync(password, 10), h, h);
      await setSession(r.lastInsertRowid);
      return Response.json({ ok: 1 });
    } catch { return Response.json({ error: 'That email or handle is already taken.' }, { status: 400 }); }
  }
  const u = db.prepare('select * from users where email=?').get((email || '').toLowerCase());
  if (!u || !bcrypt.compareSync(password || '', u.hash)) return Response.json({ error: 'Wrong email or password.' }, { status: 401 });
  await setSession(u.id);
  return Response.json({ ok: 1 });
}
