import { getUser } from '@/lib/auth';
export async function POST(req) {
  const u = await getUser(); if (!u) return Response.json({ error: 'Sign in first.' }, { status: 401 });
  if (u.plan !== 'pro') return Response.json({ error: 'AI writing is a Pro feature. Upgrade to unlock it.' }, { status: 402 });
  if (!process.env.ANTHROPIC_API_KEY) return Response.json({ error: 'Set ANTHROPIC_API_KEY on the server.' }, { status: 500 });
  const { title, kind } = await req.json();
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 300,
      messages: [{ role: 'user', content: `Write a punchy 2-sentence storefront description (max 220 characters, no hashtags, no quotes) for a creator's ${kind} called "${title}". Say what the buyer gets and why it's worth it. Output only the description.` }],
    }),
  });
  if (!r.ok) return Response.json({ error: 'AI request failed. Check your API key.' }, { status: 502 });
  const d = await r.json();
  return Response.json({ text: d.content?.[0]?.text?.trim() || '' });
}
