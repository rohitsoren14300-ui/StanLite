import Stripe from 'stripe';
import db from '@/lib/db';
export async function POST(req) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  let e;
  try { e = stripe.webhooks.constructEvent(await req.text(), req.headers.get('stripe-signature'), process.env.STRIPE_WEBHOOK_SECRET); }
  catch { return new Response('Bad signature', { status: 400 }); }
  const o = e.data.object;
  if (e.type === 'checkout.session.completed') db.prepare("update users set plan='pro', stripe_customer=? where id=?").run(o.customer, o.client_reference_id);
  if (e.type === 'customer.subscription.deleted') db.prepare("update users set plan='free' where stripe_customer=?").run(o.customer);
  return new Response('ok');
}
