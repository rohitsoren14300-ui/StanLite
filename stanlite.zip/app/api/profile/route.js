import db from '@/lib/db';
import { getUser } from '@/lib/auth';
export async function POST(req) {
  const u = await getUser(); if (!u) return Response.json({}, { status: 401 });
  const { name, bio } = await req.json();
  db.prepare('update users set name=?, bio=? where id=?').run((name || '').slice(0, 60), (bio || '').slice(0, 200), u.id);
  return Response.json({ ok: 1 });
}
